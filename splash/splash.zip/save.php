<?php

if($_REQUEST['email']) {

require_once('bronto_api.inc');

// Get the list that the user is subscribing to, depending on context
$list = 'New York Senate Updates';

$bronto = new bronto_api('newyorksenate', 'newyorksenate', 'Agency4Building');

$emailaddr = $_REQUEST['email'];
//$emailexplode = explode('@', $emailaddr);
//$emailaddr = str_replace('.', '', $emailexplode[0]) . '@' . $emailexplode[1]; 

// Add the email to the mailing list
$response = $bronto->add_email_to_list($emailaddr, $list);
if (!$response) {
  print 'Error entered address: ' . $bronto->get_error_code() . "<br/>" . $bronto->get_error_message();
  return;
}

// Update the fields
$fields = array();
if ($_REQUEST['mobile'] != '') {
  $fields['mobile'] = $_REQUEST['mobile'];
  $_SESSION['bronto_mobile'] = $_REQUEST['mobile'];
}
if (count($fields)) {
  $response = $bronto->update_fields($emailaddr, $fields);
  if (!$response) {
    print 'Error mobile: ' . $bronto->get_error_code() . "<br/>" . $bronto->get_error_message();
    return;
  }
}

// Send confirmation email
$body = strtr('You have successfully subscribed to the following !site mailing lists:

!lists

If this has been in error, you can unsubscribe here:

!unsubscribe_link

Thanks,
The !site Team', array('!site' => 'NY State Senate', '!lists' => $list, '!unsubscribe_link' => '%%!unsubscribe_url%%'));

//$body = t(variable_get('bronto_subscription_confirm_body', nyss_signup_confirm_body_default()), array('!site' => variable_get('site_name', ''), '!lists' => $list, '!unsubscribe_link' => '%%!unsubscribe_url%%'));

$response = $bronto->send_message(
  '',
  'webmaster@senate.state.ny.us',
  $emailaddr,
  strtr('Confirmation of subscription to !list mailing list', array('!list' => $list)),
  preg_replace('/\n/', '<br />', $body),
  'html',
  'contact'
);

if (!$response) {
    print 'Error sending email: ' . $bronto->get_error_code() . "<br/>" . $bronto->get_error_message();
    return;
  }
else {
  $info = '<p>Successfully added ' . $_REQUEST['email'];
  if ($_REQUEST['mobile']) {
    $info .= ' with SMS number ' . $_REQUEST['mobile'];
  }
  $info .= ' to our database. Thank you!</p><p>You will receive an email confirmation of your request shortly.</p>';
}

$_SESSION['bronto_email'] = $form_state['values']['email'];
$_SESSION['bronto_list'] = $list;

}

else { $info = '<p>Invalid request!</p>'; } ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<head>
  <title>Your New York State: Online May 8</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link type="text/css" rel="stylesheet" media="all" href="splash.css" /
</head>
<body class="body">

<div id="main-splash">

<div id="info">
<?php print $info; ?>
<p><a href="index.html" style="text-decoration: underline;">Go back</a></p>
</div>

</div>

</body>
</html>